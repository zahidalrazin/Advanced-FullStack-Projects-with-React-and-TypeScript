'use client';

function loading() {
  return <span className='text-xl capitalize'>loading tours...</span>;
}
export default loading;
