function AboutPage() {
  return (
    <div>
      <h1 className='text-7xl'>AboutPage</h1>
    </div>
  );
}
export default AboutPage;
